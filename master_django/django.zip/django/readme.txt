This directory contains the BSD-licensed Django library, version 1.0.4

(C) Django project

http://www.djangoproject.com/

